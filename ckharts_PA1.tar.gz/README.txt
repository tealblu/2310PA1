Hello! This is the readme for Charlie Hartsell's PA1.

Problems I encountered and how I solved them:
- I had a severe injury the week I planned to start this.
  It knocked me out for a few days and I'm just now (March 13) able to
  type again. Dr. Feaster gave me a 24 hour extension but with
  my other work, I dont know if I'll get this done on time. I guess
  I'll solve this by working hard, scheduling correctly, and staying
  up late.
- My first entry in the output list was always garbage data. I have absolutely
  no idea as to what's causing this.
- I'm getting a couple errors pertaining to assigning different types
  of pointers to each other. I can't figure out how to work around this but
  I'm definitely trying.


My thoughts:
- A lot of the function headers Dr. Feaster gave us had some weird
  code with no real explanation. For example, some of the functions required
  us to use a pointer to a pointer to a node. I don't quite understand why. It
  caused a lot of errors in my code.

Resources:
- Given internet links
- Geeksforgeeks pages on c
- cppreference.com
- The textbook for this class
